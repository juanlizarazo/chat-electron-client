# chat-electron-client

Desktop client for the server project [chat-nodejs-serice](https://github.com/juanlizarazo/chat-nodejs-serice)

## Stack

Electron wrapping copy of static assets (html/css/js) from web version.
It connects to web version server

## Run from source with electron

    # clone this repo
    npm i & npm start

